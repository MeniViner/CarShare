// import React from 'react';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faBarsStaggered, faCog } from '@fortawesome/free-solid-svg-icons';
// import SideNavigation from '../components/sideNavigation';


// const Top = () => {

//     return (
//         <>
//             <div className="top">
//                 <div className="left-icon icon bt" onClick={openSideNav}>
//                     <FontAwesomeIcon icon={faBarsStaggered} />
//                 </div>
//                 <div className="right-icon icon bt">
//                     <FontAwesomeIcon icon={faCog} />
//                 </div>
//             </div>    
//         </>
//     );
// };

// export default Top;