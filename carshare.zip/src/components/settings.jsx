import React from 'react';


const Settings = () => {

    return (
        <>
            <div className="user-settings">
                <h1> settings page </h1>
                
            </div>    
        </>
    );
};

export default Settings;