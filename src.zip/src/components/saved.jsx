import React from 'react';


const Saved = () => {

    return (
        <>
            <div className="saved-cars">
                <h1>your saved cars</h1>
            </div>    
        </>
    );
};

export default Saved;