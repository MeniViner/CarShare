import React from "react";


const Top = () => {


    return (
        <>
            <div className="top">

                <h3 >car share app</h3>
            </div>    
        </>
    );
};

export default Top;
