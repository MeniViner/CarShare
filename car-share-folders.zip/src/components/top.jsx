import React from 'react';



const Top = ({userName}) => {

    return (
        <>
            <div className="top">
                <h1> wellcome back </h1>
                {/* <h1>Wellcome back {userName} </h1> */}
            </div>    
        </>
    );
};

export default Top;