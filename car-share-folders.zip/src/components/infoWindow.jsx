import React from 'react';
import ThemeToggle from './design/themeToggle';
import { calculateDistance } from '../utils/distanceCalculator';

const CarInfoWindow = ({ selectedCar, toggleTheme, userLocation }) => {

  const distance = calculateDistance(userLocation, selectedCar.coordinates);

  return (
    <div className="popup-window">
      <img
        src={selectedCar.image}
        alt={`${selectedCar.brand} ${selectedCar.model}`}
      />
      <h2>{selectedCar.brand} {selectedCar.model}</h2>
      <p>Category: {selectedCar.category}</p>
      <p>Seats: {selectedCar.seats}</p>
      <p>Year: {selectedCar.year}</p>
      <p>Price per Hour: ${selectedCar.pricePerHour}</p>
      <p>Distance from your location: {distance}</p>
      <ThemeToggle toggleTheme={toggleTheme} />

    </div>
  );
};

export default CarInfoWindow;
